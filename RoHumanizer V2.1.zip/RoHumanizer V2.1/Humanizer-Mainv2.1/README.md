
## For infos about this version look into the changelogs folder when started the first time!


### Join my discord: discord.gg/zsGTqgnsmK


###### Made by TheZ


