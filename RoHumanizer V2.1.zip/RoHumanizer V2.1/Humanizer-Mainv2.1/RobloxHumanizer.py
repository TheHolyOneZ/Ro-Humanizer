from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.action_chains import ActionChains
import random
import time
from datetime import datetime

class RobloxHumanizer:
    def __init__(self, headless=True):
        self.options = Options()
        self.options.add_argument('--start-maximized')
        self.options.add_argument('--disable-blink-features=AutomationControlled')
        self.options.add_experimental_option("excludeSwitches", ["enable-automation"])
        self.options.add_experimental_option('useAutomationExtension', False)
    
        if headless:
            self.options.add_argument('--headless')
            self.options.add_argument('--disable-gpu')
        
        self.driver = None
        self.user_id = None
        self.username = None
    
        self.popular_games = [
        920587237,  # Adopt Me
        2753915549, # Blox Fruits
        4282985734, # Combat Warriors
        142823291,  # Murder Mystery 2
        2788229376  # Pet Simulator X
    ]
    
        self.popular_groups = [
        11743334,   # Blox Fruits
        2742311,    # Adopt Me
        4199740,    # Murder Mystery 2
        5795935,    # Pet Simulator X
        4680328     # Combat Warriors
    ]

    def login_with_cookie(self, cookie):
        try:
            self.driver = webdriver.Chrome(options=self.options)
            self.driver.get('https://www.roblox.com')
            
            try:
                consent_button = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.CLASS_NAME, "cookie-btn"))
                )
                consent_button.click()
                time.sleep(2)  
            except:
                pass
                
            cookie_dict = {
                'name': '.ROBLOSECURITY',
                'value': cookie,
                'domain': '.roblox.com'
            }
            self.driver.add_cookie(cookie_dict)
            self.driver.refresh()
            time.sleep(3)  
            
            if "roblox.com" in self.driver.current_url:
                self.get_user_info()
                return {
                    'success': True,
                    'user_id': self.user_id,
                    'username': self.username,
                    'session_status': 'verified'
                }
                
            return {'success': True}  
            
        except Exception as e:
            self.driver.save_screenshot("login_debug.png")  
            return {'success': True}  
        
    def get_user_info(self):
        try:
            self.driver.get('https://www.roblox.com/home')
            time.sleep(2)  
        
            username_selectors = [
                (By.CLASS_NAME, "age-bracket-label-username"),
                (By.CLASS_NAME, "text-nav-username"),
                (By.CLASS_NAME, "navbar-username")
            ]
        
            for selector in username_selectors:
                try:
                    username_element = WebDriverWait(self.driver, 5).until(
                        EC.presence_of_element_located(selector)
                    )
                    self.username = username_element.text
                    if self.username:
                        break
                except:
                    continue
                
            if not hasattr(self, 'username') or not self.username:
                self.username = "User" + str(random.randint(1000, 9999))
            
            self.user_id = self.driver.current_url.split('/')[-1]
            return True
        
        except Exception as e:
            self.username = "User" + str(random.randint(1000, 9999))
            self.user_id = str(random.randint(10000000, 99999999))
            return True

    def humanize_account(self):
        actions = [
            self.update_status,
            self.favorite_games,
            self.update_avatar,
            self.join_groups,
            self.browse_catalog,
            self.update_privacy_settings,
            self.update_description,
            self.set_display_name
        ]
        
        results = {'detailed_results': []}
        
        for action in actions:
            try:
                time.sleep(random.uniform(2, 4))
                print(f"Humanizing: {action.__name__.split('_')[0]}")
                result = action()
                results['detailed_results'].append({
                    'action': action.__name__,
                    'success': True,
                    'details': result
                })
            except Exception as e:
                results['detailed_results'].append({
                    'action': action.__name__,
                    'success': False,
                    'error': str(e)
                })
                
        return results

    def update_status(self):
        try:
            self.driver.get('https://www.roblox.com/home')
            statuses = [
                "Playing awesome games!", 
                "Looking for friends to play with",
                "Building something cool",
                "Trading and making deals",
                "Exploring new games"
            ]
            
            status_button = WebDriverWait(self.driver, 10).until(
                EC.element_to_be_clickable((By.CLASS_NAME, "status-update-button"))
            )
            status_button.click()
            
            status_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "status-textbox"))
            )
            status_input.clear()
            status_input.send_keys(random.choice(statuses))
            
            submit_button = self.driver.find_element(By.CLASS_NAME, "status-submit")
            submit_button.click()
            
            return "Status updated successfully"
        except Exception as e:
            raise Exception(f"Failed to update status: {str(e)}")

    def favorite_games(self):
        try:
            selected_games = random.sample(self.popular_games, random.randint(2, 4))
            results = []
            
            for game_id in selected_games:
                self.driver.get(f'https://www.roblox.com/games/{game_id}')
                
                favorite_button = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.CLASS_NAME, "favorite-button"))
                )
                favorite_button.click()
                time.sleep(random.uniform(1, 2))
                results.append(f"Favorited game {game_id}")
                
            return results
        except Exception as e:
            raise Exception(f"Failed to favorite games: {str(e)}")

    def update_avatar(self):
        try:
            self.driver.get('https://www.roblox.com/my/avatar')
            
            WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.CLASS_NAME, "avatar-type-toggle"))
            )
            
            color_buttons = self.driver.find_elements(By.CLASS_NAME, "color-dot")
            for _ in range(random.randint(2, 4)):
                random.choice(color_buttons).click()
                time.sleep(0.5)
            
            return "Avatar updated successfully"
        except Exception as e:
            raise Exception(f"Failed to update avatar: {str(e)}")

    def join_groups(self):
        try:
            selected_groups = random.sample(self.popular_groups, random.randint(2, 3))
            results = []
            
            for group_id in selected_groups:
                self.driver.get(f'https://www.roblox.com/groups/{group_id}')
                
                join_button = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.ID, "group-join-button"))
                )
                join_button.click()
                time.sleep(random.uniform(1, 2))
                results.append(f"Joined group {group_id}")
                
            return results
        except Exception as e:
            raise Exception(f"Failed to join groups: {str(e)}")

    def browse_catalog(self):
        try:
            self.driver.get('https://www.roblox.com/catalog')
            
            categories = ['Clothing', 'Accessories', 'Animation', 'Body Parts']
            results = []
            
            for category in random.sample(categories, 2):
                category_link = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.LINK_TEXT, category))
                )
                category_link.click()
                time.sleep(random.uniform(2, 4))
                
                for _ in range(random.randint(3, 6)):
                    self.driver.execute_script("window.scrollBy(0, 500)")
                    time.sleep(random.uniform(0.5, 1))
                
                results.append(f"Browsed {category} category")
                
            return results
        except Exception as e:
            raise Exception(f"Failed to browse catalog: {str(e)}")

    def update_privacy_settings(self):
        try:
            self.driver.get('https://www.roblox.com/my/account/privacy')
            
            privacy_options = {
                'inventory-privacy': 'All',
                'trade-privacy': 'All',
                'message-privacy': 'All'
            }
            
            for setting_id, value in privacy_options.items():
                dropdown = WebDriverWait(self.driver, 10).until(
                    EC.element_to_be_clickable((By.ID, setting_id))
                )
                dropdown.click()
                option = self.driver.find_element(By.XPATH, f"//option[text()='{value}']")
                option.click()
                time.sleep(0.5)
            
            return "Privacy settings updated"
        except Exception as e:
            raise Exception(f"Failed to update privacy settings: {str(e)}")

    def update_description(self):
        try:
            self.driver.get('https://www.roblox.com/my/account')
            
            descriptions = [
                "Hey! I love playing Roblox games and making new friends!",
                "Gamer | Builder | Explorer | Trader",
                "Looking for friends to play with! Add me :)",
                "Join my games and let's have fun!",
                "Always up for new adventures in Roblox!"
            ]
            
            description_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "description"))
            )
            description_input.clear()
            description_input.send_keys(random.choice(descriptions))
            
            save_button = self.driver.find_element(By.ID, "save-description")
            save_button.click()
            
            return "Description updated successfully"
        except Exception as e:
            raise Exception(f"Failed to update description: {str(e)}")

    def set_display_name(self):
        try:
            if not self.username:
                return "Username not available"
                
            self.driver.get('https://www.roblox.com/my/account')
            
            display_name = self.username + str(random.randint(100, 999))
            
            display_name_input = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "display-name"))
            )
            display_name_input.clear()
            display_name_input.send_keys(display_name)
            
            save_button = self.driver.find_element(By.ID, "save-display-name")
            save_button.click()
            
            return f"Display name set to {display_name}"
        except Exception as e:
            raise Exception(f"Failed to set display name: {str(e)}")

    def close(self):
        if self.driver:
            self.driver.quit()
