import customtkinter as ctk
import threading
import os
import json
from datetime import datetime, timedelta
import logging
import queue
import sys
from RobloxHumanizer import RobloxHumanizer
import random
import time
import traceback
from PIL import Image
import webbrowser
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class ModernHumanizerGUI:
    def __init__(self):
        self.setup_logging()
        self.setup_variables()
        self.load_settings()
        self.initialize_gui()
        self.lock = threading.Lock()
        self.account_queue = queue.Queue()
        self.stop_flag = threading.Event()
        self.active_threads_list = []
        self.successful_accounts = []
        self.failed_accounts = []
        self.processing_times = []
        self.create_changelog()

    def create_changelog(self):
        changelog_content = """
ROBLOX HUMANIZER v2.1 CHANGELOG

Release Date: 22 January 2025

NEW FEATURES:
• Enhanced Multi-threading System
• Advanced Cookie Validation
• Auto-retry Mechanism
• Headless Mode Support

IMPROVEMENTS:
• Optimized Browser Management
• Reduced Memory Usage
• Faster Account Processing
• Improved Error Handling

FIXES:
• Fixed thread management issues
• Resolved cookie validation bugs
• Better memory cleanup

TECHNICAL:
• Updated ChromeDriver compatibility
• Improved logging system
• Enhanced data export format
• Better resource management

KNOWN ISSUES:
• Will shown as Failed but isnt
• GUI may freeze (rare)
• Browser not stopping even after hitting stop button

Made by TheZ
Discord: discord.gg/zsGTqgnsmK
"""
    
        if not os.path.exists("logs"):
            os.makedirs("logs")
        
        with open("changelogs/changelog.txt", "w", encoding='utf-8') as f:
            f.write(changelog_content)
    
        self.log("Changelog created successfully")




    def validate_cookie(self, cookie):
        """Validates Roblox cookie format and security"""
        if not cookie or len(cookie) < 100:
            return False
        
        required_prefix = '_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_'
        return cookie.startswith(required_prefix)
    


    def update_stats(self):
        """Updates all GUI statistics and displays"""
        try:
            total = max(self.completed + self.failed, 1)
            success_rate = (self.completed / total) * 100
            active_threads = len([t for t in self.active_threads_list if t.is_alive()])

            stats_updates = {
            self.completed_count: str(self.completed),
            self.failed_count: str(self.failed),
            self.active_threads: str(active_threads),
            self.accounts_loaded: str(len(self.accounts))
        }

            for element, value in stats_updates.items():
                if hasattr(element, 'configure'):
                    element.configure(text=value)

            status_message = f"Stats Updated | Completed: {self.completed} | Failed: {self.failed} | Active: {active_threads}"
            self.log(status_message)
        
            if self.settings.get('webhook_enabled'):
                self.send_webhook_update(status_message, "INFO")

        except Exception as e:
            error_message = f"Failed to update stats: {str(e)}"
            self.log(error_message, "ERROR")
            if self.settings.get('webhook_enabled'):
                    self.send_webhook_update(error_message, "ERROR")


    def load_settings(self):
        try:
            with open('config/config.json', 'r') as f:
                self.settings = json.load(f)
        except FileNotFoundError:
            self.settings = {
                'max_threads': 3,
                'delay_range_min': 30,
                'delay_range_max': 45,
                'auto_export': True,
                'retry_attempts': 3,
                'proxy_enabled': False,
                'proxy_list': [],
                'webhook_enabled': False,
                'webhook_url': '',
                'notification_sound': True,
                'auto_retry': False,
                'save_failed': True,
                'cookie_validation': True
            }
            self.save_settings()

    def save_settings(self):
        with open('config/config.json', 'w') as f:
            json.dump(self.settings, f, indent=4)

    def setup_logging(self):
        log_dir = "logs"
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        log_file = os.path.join(log_dir, f'humanizer_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    
        logging.basicConfig(
            level=logging.DEBUG,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler(sys.stdout)
            ]
        )

    def setup_variables(self):
        self.accounts = []
        self.completed = 0
        self.failed = 0
        self.start_time = None
        self.processing_accounts = set()
        self.successful_accounts = []
        self.failed_accounts = []
        self.is_running = False
        self.current_view = "dashboard"
        self.processing_times = []

    def initialize_gui(self):
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")
        
        self.root = ctk.CTk()
        self.root.geometry("1400x900")
        self.root.title("Roblox Account Humanizer v2.1 - TheZ")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.iconbitmap("assets/icon.ico")
        
        self.create_main_container()
        self.create_sidebar()
        self.create_main_content()
        self.create_footer()
        self.setup_tooltips()
    def show_settings(self):
        self.settings_window = ctk.CTkToplevel(self.root)
        self.settings_window.title("Settings")
        self.settings_window.geometry("900x700")
        self.settings_window.grab_set() 
        self.settings_window.iconbitmap("assets/icon.ico")

        settings_notebook = ctk.CTkTabview(self.settings_window)
        settings_notebook.pack(fill="both", expand=True, padx=20, pady=20)

        general_tab = settings_notebook.add("General")
        self.create_general_settings(general_tab)

        proxy_tab = settings_notebook.add("Proxy")
        self.create_proxy_settings(proxy_tab)

        webhook_tab = settings_notebook.add("Webhook")
        self.create_webhook_settings(webhook_tab)

        button_frame = ctk.CTkFrame(self.settings_window)
        button_frame.pack(fill="x", padx=20, pady=10)

        ctk.CTkButton(
            button_frame,
            text="Apply Settings",
            command=self.apply_settings,
            fg_color="#2ecc71",
            width=120
        ).pack(side="right", padx=5)

        ctk.CTkButton(
            button_frame,
            text="Cancel",
            command=self.settings_window.destroy,
            fg_color="#e74c3c",
            width=120
        ).pack(side="right", padx=5)

    def create_general_settings(self, parent):
   
        thread_frame = ctk.CTkFrame(parent)
        thread_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(thread_frame, text="Threading", font=("Roboto", 14, "bold")).pack(pady=5)
        
        self.thread_slider = ctk.CTkSlider(
            thread_frame,
            from_=1,
            to=10,
            number_of_steps=9,
            command=lambda v: self.thread_label.configure(text=f"Max Threads: {int(v)}")
        )
        self.thread_slider.set(self.settings['max_threads'])
        self.thread_slider.pack(fill="x", padx=20, pady=5)
        
        self.thread_label = ctk.CTkLabel(thread_frame, text=f"Max Threads: {self.settings['max_threads']}")
        self.thread_label.pack()

        delay_frame = ctk.CTkFrame(parent)
        delay_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(delay_frame, text="Delay Range (seconds)", font=("Roboto", 14, "bold")).pack(pady=5)
        
        delay_input_frame = ctk.CTkFrame(delay_frame)
        delay_input_frame.pack(fill="x", padx=20)
        
        self.delay_min = ctk.CTkEntry(delay_input_frame, width=100)
        self.delay_min.insert(0, str(self.settings['delay_range_min']))
        self.delay_min.pack(side="left", padx=5)
        
        ctk.CTkLabel(delay_input_frame, text="to").pack(side="left", padx=5)
        
        self.delay_max = ctk.CTkEntry(delay_input_frame, width=100)
        self.delay_max.insert(0, str(self.settings['delay_range_max']))
        self.delay_max.pack(side="left", padx=5)

        auto_frame = ctk.CTkFrame(parent)
        auto_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(auto_frame, text="Automation", font=("Roboto", 14, "bold")).pack(pady=5)
        
        self.auto_export_var = ctk.BooleanVar(value=self.settings['auto_export'])
        self.auto_retry_var = ctk.BooleanVar(value=self.settings['auto_retry'])
        self.save_failed_var = ctk.BooleanVar(value=self.settings['save_failed'])
        
        switches = [
            ("Auto Export Results", self.auto_export_var),
            ("Auto Retry Failed", self.auto_retry_var),
            ("Save Failed Accounts", self.save_failed_var)
        ]
        
        for text, var in switches:
            switch = ctk.CTkSwitch(
                auto_frame,
                text=text,
                variable=var,
                button_color="#2ecc71",
                button_hover_color="#27ae60"
            )
            switch.pack(anchor="w", padx=20, pady=5)

        headless_frame = ctk.CTkFrame(parent)
        headless_frame.pack(fill="x", padx=20, pady=10)
    
        ctk.CTkLabel(headless_frame, text="Browser Settings", font=("Roboto", 14, "bold")).pack(pady=5)
    
        self.headless_var = ctk.BooleanVar(value=self.settings.get('headless_mode', True))
        headless_switch = ctk.CTkSwitch(
        headless_frame,
        text="Headless Mode",
        variable=self.headless_var,
        button_color="#2ecc71",
        button_hover_color="#27ae60"
    )
        headless_switch.pack(anchor="w", padx=20, pady=5)

    def create_proxy_settings(self, parent):
        proxy_enable_frame = ctk.CTkFrame(parent)
        proxy_enable_frame.pack(fill="x", padx=20, pady=10)
        
        self.proxy_enabled_var = ctk.BooleanVar(value=self.settings['proxy_enabled'])
        proxy_switch = ctk.CTkSwitch(
            proxy_enable_frame,
            text="Enable Proxy Support",
            variable=self.proxy_enabled_var,
            button_color="#2ecc71",
            button_hover_color="#27ae60"
        )
        proxy_switch.pack(pady=10)
        
        self.proxy_text = ctk.CTkTextbox(parent, height=200)
        self.proxy_text.pack(fill="x", padx=20, pady=10)
        
        if self.settings['proxy_list']:
            self.proxy_text.insert("1.0", "\n".join(self.settings['proxy_list']))

    def create_webhook_settings(self, parent):
        webhook_enable_frame = ctk.CTkFrame(parent)
        webhook_enable_frame.pack(fill="x", padx=20, pady=10)
        
        self.webhook_enabled_var = ctk.BooleanVar(value=self.settings['webhook_enabled'])
        webhook_switch = ctk.CTkSwitch(
            webhook_enable_frame,
            text="Enable Discord Webhook",
            variable=self.webhook_enabled_var,
            button_color="#2ecc71",
            button_hover_color="#27ae60"
        )
        webhook_switch.pack(pady=10)
        
        webhook_url_frame = ctk.CTkFrame(parent)
        webhook_url_frame.pack(fill="x", padx=20, pady=10)
        
        ctk.CTkLabel(webhook_url_frame, text="Webhook URL:").pack(pady=5)
        
        self.webhook_url = ctk.CTkEntry(webhook_url_frame, width=400)
        self.webhook_url.insert(0, self.settings['webhook_url'])
        self.webhook_url.pack(pady=5)
    def apply_settings(self):
        try:
            new_settings = {
                'max_threads': int(self.thread_slider.get()),
                'delay_range_min': float(self.delay_min.get()),
                'delay_range_max': float(self.delay_max.get()),
                'auto_export': self.auto_export_var.get(),
                'auto_retry': self.auto_retry_var.get(),
                'save_failed': self.save_failed_var.get(),
                'proxy_enabled': self.proxy_enabled_var.get(),
                'proxy_list': self.proxy_text.get("1.0", "end-1c").splitlines(),
                'webhook_enabled': self.webhook_enabled_var.get(),
                'webhook_url': self.webhook_url.get()
            }
            
            self.settings.update(new_settings)
            self.save_settings()
            
            self.log("Settings updated successfully")
            self.settings_window.destroy()
            
        except Exception as e:
            self.show_error("Settings Error", f"Failed to save settings: {str(e)}")

    def validate_cookie_format(self, cookie):
        """Validates Roblox cookie format"""
        if not cookie.strip():
            return False
        
        required_parts = [
        '_|WARNING:-DO-NOT-SHARE-THIS.--Sharing-this-will-allow-someone-to-log-in-as-you-and-to-steal-your-ROBUX-and-items.|_'
    ]
    
        return len(cookie) > 100 and required_parts[0] in cookie

    def load_cookies(self):
        try:
            if not os.path.exists("config/cookies.txt"):
                self.log("cookies.txt not found!", "ERROR")
                return
                
            with open("config/cookies.txt", "r") as f:
                cookies = [line.strip() for line in f.readlines()]
            
            valid_cookies = []
            for cookie in cookies:
                if self.validate_cookie_format(cookie):
                    valid_cookies.append(cookie)
                else:
                    self.log(f"Invalid cookie format detected", "WARNING")
                    self.send_webhook_update("Invalid cookie format detected", "WARNING")
        
            self.accounts = valid_cookies
            self.accounts_loaded.configure(text=str(len(self.accounts)))
        
            status_message = f"Successfully loaded {len(self.accounts)} valid cookies"
            self.log(status_message)
            self.send_webhook_update(status_message, "INFO")
            
        except Exception as e:
            error_message = f"Error loading cookies: {str(e)}"
            self.log(error_message, "ERROR")
            self.send_webhook_update(error_message, "ERROR")

    def humanize_account(self, account):
        try:
            humanizer = RobloxHumanizer(headless=self.settings.get('headless_mode', True))
            self.log(f"Attempting login with enhanced security...")
            
            if not self.validate_cookie(account):
                raise ValueError("Invalid cookie format")
                
            if self.settings['proxy_enabled'] and self.settings['proxy_list']:
                proxy = random.choice(self.settings['proxy_list'])
                humanizer.set_proxy(proxy)

            login_result = humanizer.login_with_cookie(account)

            if login_result['success']:
                self.log(f"Successfully logged in as {login_result['username']}")
                self.log(f"Account Details: ID={login_result['user_id']}, Robux={login_result.get('robux', 'N/A')}")
                self.log(f"Humanizing session starting")
                
                retry_count = 0
                while retry_count < self.settings['retry_attempts']:
                    try:
                        results = humanizer.humanize_account()
                        if self.process_humanization_results(results, login_result['username']):
                            with self.lock:
                                self.completed += 1
                                self.successful_accounts.append({
                                    'cookie': account,
                                    'username': login_result['username'],
                                    'user_id': login_result['user_id']
                                })
                            break
                        else:
                            retry_count += 1
                            if retry_count < self.settings['retry_attempts']:
                                self.log(f"Retrying humanization... Attempt {retry_count + 1}")
                                time.sleep(random.uniform(2, 5))
                    except Exception as e:
                        retry_count += 1
                        self.log(f"Humanization attempt {retry_count} failed: {str(e)}", "WARNING")
                
                if retry_count == self.settings['retry_attempts']:
                    with self.lock:
                        self.failed += 1
                        self.failed_accounts.append(account)
                    
            else:
                error_msg = login_result.get('error', 'Unknown error')
                self.log(f"Login failed: {error_msg}", "ERROR")
                with self.lock:
                    self.failed += 1
                    self.failed_accounts.append(account)

        except Exception as e:
            self.log(f"Critical error during humanization: {str(e)}", "ERROR")
            with self.lock:
                self.failed += 1
                self.failed_accounts.append(account)

        finally:
            self.update_stats()
            if self.settings['webhook_enabled']:
                self.send_webhook_update(f"Account processing completed - Success: {self.completed}, Failed: {self.failed}")


    def process_humanization_results(self, results, username):
        success_count = 0
        total_actions = len(results['detailed_results'])
    
        for result in results['detailed_results']:
            if result.get('success', False):
                success_count += 1
                self.log(f"[SUCCESS] {username}: {result['action']} completed")
            else:
                self.log(f"[FAILED] {username}: {result['action']} - {result.get('error', 'Unknown error')}", "WARNING")
    
        success_rate = success_count / total_actions
        self.log(f"Account {username}")

        if self.settings['webhook_enabled']:
            self.send_webhook_update(f"Account {username} processed - Success Rate: {success_rate:.1f}%")

        return success_rate >= 10
    

    def process_account_queue(self):
        while not self.stop_flag.is_set():
            try:
                try:
                    account = self.account_queue.get(timeout=1)
                except queue.Empty:
                    break
                
                start_time = time.time()
                self.humanize_account(account)
            
                processing_time = time.time() - start_time
                self.processing_times.append(processing_time)
            
                if self.settings['webhook_enabled']:
                    self.send_webhook_update(
                        f"Account processed in {processing_time:.1f}s | Remaining: {self.account_queue.qsize()}",
                        "INFO"
                    )
                
                if not self.stop_flag.is_set():
                    delay = random.uniform(
                        self.settings['delay_range_min'],
                        self.settings['delay_range_max']
                    )
                    time.sleep(delay)
                
            except Exception as e:
                self.log(f"Error in processing thread: {str(e)}", "ERROR")
            
        self.log("Processing thread finished")

    def send_webhook_update(self, message, level="INFO"):
        """Sends detailed status updates to Discord webhook"""
        if not self.settings.get('webhook_enabled') or not self.settings.get('webhook_url'):
            return
        
        try:
            import requests
        
            colors = {
            "DEBUG": 2201331,    # Blue
            "INFO": 3066993,     # Green
            "WARNING": 16776960, # Yellow
            "ERROR": 15158332,   # Red
            "ACTION": 10181046,  # Purple
            "LOGIN": 7419530,    # Cyan
            "COMPLETE": 3066993  # Green
        }
        
            active_threads = len([t for t in self.active_threads_list if t.is_alive()])
            success_rate = (self.completed / max(self.completed + self.failed, 1) * 100)
        
            embed = {
            "title": f"Humanizer Update | {level}",
            "description": message,
            "color": colors.get(level, 7506394),
            "fields": [
                {"name": "🎯 Progress", "value": f"Completed: {self.completed} | Failed: {self.failed}", "inline": True},
                {"name": "📊 Success Rate", "value": f"{success_rate:.1f}%", "inline": True},
                {"name": "⚡ Active Threads", "value": str(active_threads), "inline": True},
                {"name": "📦 Accounts Loaded", "value": str(len(self.accounts)), "inline": True},
                {"name": "⏱️ Queue Size", "value": str(self.account_queue.qsize()), "inline": True},
                {"name": "🔄 Processing", "value": str(len(self.processing_times)), "inline": True}
            ],
            "timestamp": datetime.now().isoformat()
        }
        
            requests.post(self.settings['webhook_url'], json={"embeds": [embed]})
        
        except Exception as e:
            self.log(f"Webhook error: {str(e)}", "ERROR")

    def show_error(self, title, message):
        error_window = ctk.CTkToplevel(self.root)
        error_window.title(title)
        error_window.geometry("400x200")
        error_window.grab_set()
        
        ctk.CTkLabel(
            error_window,
            text=message,
            wraplength=350
        ).pack(pady=20)
        
        ctk.CTkButton(
            error_window,
            text="OK",
            command=error_window.destroy
        ).pack(pady=10)

    def export_results(self):
        try:
            results = {
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "total_accounts": len(self.accounts),
                "completed": self.completed,
                "failed": self.failed,
                "success_rate": f"{(self.completed / max(self.completed + self.failed, 1) * 100):.1f}%",
                "successful_accounts": self.successful_accounts,
                "failed_accounts": self.failed_accounts,
                "average_processing_time": f"{sum(self.processing_times) / len(self.processing_times):.1f}s" if self.processing_times else "N/A",
                "settings_used": self.settings
            }

            filename = f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(filename, "w") as f:
                json.dump(results, f, indent=4)

            self.log(f"Results exported to {filename}")

        except Exception as e:
            self.show_error("Export Error", f"Failed to export results: {str(e)}")
    def create_main_container(self):
        self.container = ctk.CTkFrame(self.root)
        self.container.pack(fill="both", expand=True)
        
        self.sidebar = ctk.CTkFrame(self.container, width=200, corner_radius=0)
        self.sidebar.pack(side="left", fill="y", padx=0, pady=0)
        
        self.main_content = ctk.CTkFrame(self.container)
        self.main_content.pack(side="right", fill="both", expand=True, padx=20, pady=20)

    def create_sidebar(self):
        logo_label = ctk.CTkLabel(
            self.sidebar,
            text="HUMANIZER",
            font=("Roboto", 20, "bold"),
            justify="center"
        )
        logo_label.pack(pady=30)
        
        nav_buttons = [
            ("Dashboard", self.show_dashboard, "#2FA572"),
            ("Settings", self.show_settings, "#3B8ED0"),
            ("Statistics", self.show_statistics, "#C65031"),
            ("Help", self.show_help, "#8E44AD")
        ]
        
        for text, command, color in nav_buttons:
            btn = ctk.CTkButton(
                self.sidebar,
                text=text,
                command=command,
                width=160,
                height=40,
                fg_color=color,
                corner_radius=10
            )
            btn.pack(pady=10)

    def create_main_content(self):
        self.status_frame = ctk.CTkFrame(self.main_content)
        self.status_frame.pack(fill="x", pady=(0, 20))
        
        self.create_status_display()
        self.create_control_panel()
        self.create_statistics_panel()
        self.create_logs_panel()

    def create_status_display(self):
        self.status_frame = ctk.CTkFrame(self.main_content)
        self.status_frame.pack(fill="x", pady=(0, 20))
    
        self.status_text = ctk.CTkTextbox(
        self.status_frame,
        height=150,
        font=("Consolas", 12),
        wrap="word"
    )
        self.status_text.pack(fill="x", padx=20, pady=10)


    def create_control_panel(self):
        control_frame = ctk.CTkFrame(self.main_content)
        control_frame.pack(fill="x", pady=10)
        
        buttons = [
            ("Load Cookies", self.load_cookies, "#2FA572"),
            ("Start", self.start_humanizing, "#3B8ED0"),
            ("Pause", self.pause_processing, "#F39C12"),
            ("Stop", self.stop_all_threads, "#E74C3C"),
            ("Export", self.export_results, "#8E44AD"),
            ("Clear Logs", self.clear_logs, "#95A5A6")
        ]
        
        for text, command, color in buttons:
            btn = ctk.CTkButton(
                control_frame,
                text=text,
                command=command,
                width=120,
                height=35,
                fg_color=color,
                corner_radius=10
            )
            btn.pack(side="left", padx=5)

    def create_statistics_panel(self):
        stats_frame = ctk.CTkFrame(self.main_content)
        stats_frame.pack(fill="x", pady=10)
        
        stats = [
            ("Accounts Loaded", "accounts_loaded"),
            ("Completed", "completed_count"),
            ("Failed", "failed_count"),
            ("Active Threads", "active_threads")
        ]
        
        for text, attr in stats:
            stat_container = ctk.CTkFrame(stats_frame)
            stat_container.pack(side="left", expand=True, padx=5, pady=5)
            
            ctk.CTkLabel(
                stat_container,
                text=text,
                font=("Roboto", 12)
            ).pack()
            
            setattr(self, attr, ctk.CTkLabel(
                stat_container,
                text="0",
                font=("Roboto", 16, "bold")
            ))
            getattr(self, attr).pack()

    def create_logs_panel(self):
        logs_frame = ctk.CTkFrame(self.main_content)
        logs_frame.pack(fill="both", expand=True, pady=10)
        
        self.detail_text = ctk.CTkTextbox(
            logs_frame,
            font=("Consolas", 12),
            wrap="word"
        )
        self.detail_text.pack(fill="both", expand=True, padx=10, pady=10)

    def create_footer(self):
        footer = ctk.CTkFrame(self.container)
        footer.pack(fill="x", side="bottom", pady=10)
        
        ctk.CTkLabel(
            footer,
            text="© 2025 Humanizer - TheZ",
            font=("Roboto", 10)
        ).pack()

    def on_closing(self):
        if self.is_running:
            self.stop_all_threads()
        if self.settings['auto_export']:
            self.export_results()
        self.root.destroy()

    def run(self):
        try:
            self.root.mainloop()
        except Exception as e:
            logging.critical(f"Critical error: {str(e)}")
            self.export_results()

    def show_dashboard(self):
        self.current_view = "dashboard"
    
        temp_status = None
        if hasattr(self, 'status_text'):
            temp_status = self.status_text.get("1.0", "end-1c")
    
        for widget in self.main_content.winfo_children():
            widget.destroy()
    
        self.create_status_display()
        self.create_control_panel()
        self.create_statistics_panel()
        self.create_logs_panel()
    
        if temp_status:
            self.status_text.insert("1.0", temp_status)
    
        self.update_stats()


    def show_statistics(self):
        stats_window = ctk.CTkToplevel(self.root)
        stats_window.title("Statistics")
        stats_window.geometry("800x600")

        overall_frame = ctk.CTkFrame(stats_window)
        overall_frame.pack(fill="x", padx=20, pady=10)
    
        ctk.CTkLabel(overall_frame, text="Overall Statistics", font=("Roboto", 16, "bold")).pack(pady=5)
    
        runtime = datetime.now() - self.start_time if self.start_time else timedelta(0)
        avg_time = sum(self.processing_times) / len(self.processing_times) if self.processing_times else 0
    
        stats_data = [
        ("Total Accounts", f"{len(self.accounts)}"),
        ("Completed", f"{self.completed}"),
        ("Failed", f"{self.failed}"),
        ("Success Rate", f"{(self.completed / max(self.completed + self.failed, 1) * 100):.1f}%"),
        ("Average Processing Time", f"{avg_time:.1f} seconds"),
        ("Total Runtime", str(runtime).split('.')[0])
    ]
    
        for label, value in stats_data:
            stat_frame = ctk.CTkFrame(overall_frame)
            stat_frame.pack(fill="x", padx=10, pady=5)
            ctk.CTkLabel(stat_frame, text=label).pack(side="left", padx=5)
            ctk.CTkLabel(stat_frame, text=value).pack(side="right", padx=5)

        if self.processing_times:
            self.create_performance_graph(stats_window)


    def create_performance_graph(self, parent):
        figure = plt.Figure(figsize=(6, 4))
        ax = figure.add_subplot(111)
    
        if self.processing_times:
            ax.plot(range(len(self.processing_times)), self.processing_times, 'b-')
            ax.set_title('Account Processing Performance')
            ax.set_xlabel('Account Number')
            ax.set_ylabel('Processing Time (s)')
        
            canvas = FigureCanvasTkAgg(figure, parent)
            canvas.draw()
            canvas.get_tk_widget().pack(fill="both", expand=True, padx=20, pady=10)

    def show_help(self):
        help_window = ctk.CTkToplevel(self.root)
        help_window.title("Help & Documentation")
        help_window.geometry("800x600")

        tabview = ctk.CTkTabview(help_window)
        tabview.pack(fill="both", expand=True, padx=20, pady=20)

        getting_started = tabview.add("Getting Started")
        self.add_help_section(getting_started, [
        ("Welcome to Roblox Account Humanizer", 
         "This tool helps automate and humanize Roblox accounts safely and efficiently."),
        ("Quick Start Guide", """
        1. Load your cookies from cookies.txt
        2. Configure desired settings
        3. Click 'Start Humanizing' to begin
        4. Monitor progress in real-time
        5. Export results when finished
        """)
    ])

        features = tabview.add("Features")
        self.add_help_section(features, [
        ("Account Management", "Safely manage multiple Roblox accounts"),
        ("Humanization Actions", "Performs natural human-like actions"),
        ("Multi-threading", "Process multiple accounts simultaneously"),
        ("Export & Analytics", "Detailed reports and statistics")
    ])

        support = tabview.add("Support")
        support_frame = ctk.CTkFrame(support)
        support_frame.pack(fill="both", expand=True, padx=20, pady=20)
    
        ctk.CTkLabel(support_frame, text="Need Help?", font=("Roboto", 16, "bold")).pack(pady=10)
    
        discord_button = ctk.CTkButton(
            support_frame,
        text="Join Discord Server",
        command=lambda: webbrowser.open("discord.gg/zsGTqgnsmK")
    )
        discord_button.pack(pady=10)

    def add_help_section(self, parent, content):
        for title, description in content:
            section = ctk.CTkFrame(parent)
            section.pack(fill="x", padx=20, pady=10)
        
            ctk.CTkLabel(section, text=title, font=("Roboto", 14, "bold")).pack(pady=5)
            ctk.CTkLabel(section, text=description, wraplength=600).pack(pady=5)

    def start_humanizing(self):
        if not self.accounts:
            self.log("No accounts loaded!", "ERROR")
            return

        if not self.is_running:
            self.is_running = True
            self.start_time = datetime.now()
            self.log("Starting humanization process...")
        
            while not self.account_queue.empty():
                self.account_queue.get()
            
            for account in self.accounts:
                self.account_queue.put(account)
            
            max_threads = min(self.settings['max_threads'], len(self.accounts))
            for _ in range(max_threads):
                thread = threading.Thread(target=self.process_account_queue)
                self.active_threads_list.append(thread)
                thread.start()
            
            self.log(f"Started {max_threads} processing threads")
            self.update_stats()
    def pause_processing(self):
        if self.is_running:
            self.stop_flag.set()
            self.is_running = False
            self.log("Pausing all active processes...", "WARNING")
        
            for thread in self.active_threads_list:
                if thread.is_alive():
                    thread.join(timeout=1.0)
                
            self.active_threads_list.clear()
            self.update_stats()
            self.log("Processing paused - Click Start to resume")
        else:
            self.log("No active processes to pause")
    def stop_all_threads(self):
        self.stop_flag.set()
        self.is_running = False
        self.log("Stopping all active processes...", "WARNING")

        while not self.account_queue.empty():
            self.account_queue.get()

        for thread in self.active_threads_list:
            if thread.is_alive():
                thread.join(timeout=0.5)

        try:
            from selenium import webdriver
            from selenium.webdriver.common.by import By
            drivers = webdriver.Chrome.get_instances()
            for driver in drivers:
                driver.quit()
        except:
            pass

        self.active_threads_list.clear()
        self.processing_accounts.clear()
    
        if sys.platform.startswith('win'):
            os.system('taskkill /f /im chromedriver.exe')
            os.system('taskkill /f /im chrome.exe')
        else:
            os.system('pkill chromedriver')
            os.system('pkill chrome')

        self.update_stats()
        self.log("All processes stopped successfully")


    def clear_logs(self):
        self.status_text.delete("1.0", "end")
        self.detail_text.delete("1.0", "end")
        self.log("Logs cleared successfully")
    
        if hasattr(self, 'log_history'):
            self.log_history = []
        
        if self.settings.get('clear_log_file', False):
            log_file = logging.getLogger().handlers[0].baseFilename
            with open(log_file, 'w') as f:
                f.write('')

    def setup_tooltips(self):
        self.tooltips = {
        "Load Cookies": "Load account cookies from cookies.txt file",
        "Start": "Begin the humanization process",
        "Pause": "Temporarily pause all running processes",
        "Stop": "Stop all running processes",
        "Export": "Export results to JSON file",
        "Clear Logs": "Clear all displayed logs"
    }
    
        def show_tooltip(event, text):
            x, y = event.x_root + 15, event.y_root + 10
            tooltip = ctk.CTkToplevel()
            tooltip.wm_overrideredirect(True)
            tooltip.geometry(f"+{x}+{y}")
        
            label = ctk.CTkLabel(
                tooltip,
                text=text,
                fg_color="#2d3436",
                corner_radius=6,
                padx=10,
                pady=5
        )
            label.pack()
        
            def hide_tooltip():
                tooltip.destroy()
            
            tooltip.bind('<Leave>', lambda e: hide_tooltip())
            event.widget.bind('<Leave>', lambda e: hide_tooltip())
    
        for button in self.button_frame.winfo_children():
            if isinstance(button, ctk.CTkButton) and button.cget("text") in self.tooltips:
                button.bind('<Enter>', lambda e, text=self.tooltips[button.cget("text")]: 
                        show_tooltip(e, text))
                
    def create_control_panel(self):
        control_frame = ctk.CTkFrame(self.main_content)
        control_frame.pack(fill="x", pady=10)
    
        self.button_frame = control_frame
    
        buttons = [
        ("Load Cookies", self.load_cookies, "#2FA572"),
        ("Start", self.start_humanizing, "#3B8ED0"),
        ("Pause", self.pause_processing, "#F39C12"),
        ("Stop", self.stop_all_threads, "#E74C3C"),
        ("Export", self.export_results, "#8E44AD"),
        ("Clear Logs", self.clear_logs, "#95A5A6")
    ]
    
        for text, command, color in buttons:
            btn = ctk.CTkButton(
                self.button_frame,
                text=text,
                command=command,
                width=120,
                height=35,
                fg_color=color,
                corner_radius=10
            )
            btn.pack(side="left", padx=5)


    def log(self, message, level="INFO"):
        timestamp = datetime.now().strftime("%H:%M:%S")
        formatted_message = f"[{timestamp}] [{level}] {message}\n"
    
        self.status_text.insert("end", formatted_message)
        self.status_text.see("end")
    
        if level == "ERROR":
            self.detail_text.insert("end", formatted_message)
            self.detail_text.see("end")
    
        logging.log(
        getattr(logging, level),
        message
    )
    
        if hasattr(self, 'log_history'):
            self.log_history.append({
            'timestamp': timestamp,
            'level': level,
            'message': message
        })

if __name__ == "__main__":
    try:
        app = ModernHumanizerGUI()
        app.run()
    except Exception as e:
        logging.critical(f"Application crashed: {str(e)}")
        traceback.print_exc()

